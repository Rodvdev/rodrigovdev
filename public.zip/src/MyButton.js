export default function MyButton() {
    return (
      <button>Soy un botón</button>
    );
  }